/*I checked it with DOM management. I used it to manage the active/deactivate states of the selected checkbox button. */

$(document).ready(function () {
    $("input[type=checkbox]").checkboxradio();
   });