
Widget:qTip2 - Pretty powerful tooltips
jquery.qtip.min.css
jquery.qtip.min.js

***************************

Plugin:jquery
jquery.js
jquery-ui.js
jquery-ui.css

DOM method
ready();
click();
attr();
html();
find();
hide();
fadeIn();
datepicker();
autocomplete();
css();
position();
match();
checkboxradio()