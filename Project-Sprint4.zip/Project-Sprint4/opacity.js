/*The d1 open slowly. hide() hides at first. fadeIn() shows the formbox in the given time. */

$(document).ready(function () {
  $('#d1').find('*').hide();
  $('#d1').find('*').fadeIn(800);
});
